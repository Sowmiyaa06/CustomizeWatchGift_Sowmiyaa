package com.example.Customizewatch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomizewatchApplicationTests {

	@Test
	void contextLoads() {
	}

}
