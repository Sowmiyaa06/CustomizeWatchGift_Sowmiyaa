package com.example.Customizewatch.Model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Theme {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
  //  @Column(name = "themeId")
	int themeId;
	String themeName;
	String themeDetails;
	int themePrice ;
	
	 @OneToOne(targetEntity=Gift.class,cascade = CascadeType.ALL)
	 @JoinColumn(referencedColumnName="giftId")
	 private Gift gift;

	public int getThemeId() {
		return themeId;
	}

	public void setThemeId(int themeId) {
		this.themeId = themeId;
	}

	public String getThemeName() {
		return themeName;
	}

	public void setThemeName(String themeName) {
		this.themeName = themeName;
	}

	public String getThemeDetails() {
		return themeDetails;
	}

	public void setThemeDetails(String themeDetails) {
		this.themeDetails = themeDetails;
	}

	public int getThemePrice() {
		return themePrice;
	}

	public void setThemePrice(int themePrice) {
		this.themePrice = themePrice;
	}

	public Gift getGift() {
		return gift;
	}

	public void setGift(Gift gift) {
		this.gift = gift;
	}

	public Theme(int themeId, String themeName, String themeDetails, int themePrice, Gift gift) {
		super();
		this.themeId = themeId;
		this.themeName = themeName;
		this.themeDetails = themeDetails;
		this.themePrice = themePrice;
		this.gift = gift;
	}

	@Override
	public String toString() {
		return "Theme [themeId=" + themeId + ", themeName=" + themeName + ", themeDetails=" + themeDetails
				+ ", themePrice=" + themePrice + ", gift=" + gift + "]";
	}

	public Theme() {
		super();
		// TODO Auto-generated constructor stub
	} 
	
	
}

